#define UTS_RELEASE "5.4.0-1021-xilinx-zynqmp"
#define UTS_UBUNTU_RELEASE_ABI 1021

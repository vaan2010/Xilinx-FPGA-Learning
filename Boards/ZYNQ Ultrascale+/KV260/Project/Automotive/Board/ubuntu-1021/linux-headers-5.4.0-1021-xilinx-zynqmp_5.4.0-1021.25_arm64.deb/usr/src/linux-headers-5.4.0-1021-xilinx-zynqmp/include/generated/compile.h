/* This file is auto generated, version 25 */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#25 SMP Thu Mar 23 18:02:32 PDT 2023"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ubuntu"
#define LINUX_COMPILER "gcc version 9.4.0 (Ubuntu 9.4.0-1ubuntu1~20.04.1)"

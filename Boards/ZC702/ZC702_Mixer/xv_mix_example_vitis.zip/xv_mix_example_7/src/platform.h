/******************************************************************************
* Copyright (C) 2008 - 2020 Xilinx, Inc.  All rights reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/


#ifndef __PLATFORM_H_
#define __PLATFORM_H_

void init_platform();
void cleanup_platform();

#endif
